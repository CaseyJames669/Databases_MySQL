﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ProtectedContent_Employees : System.Web.UI.Page
{
    EmployeesDataContext database = new EmployeesDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void employeesLinqDataSource_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        /*
        e.Result = from emp in database.LGEMPLOYEEs
                   where emp.DEPT_NAME == Convert.ToInt32(departmentDropDownList1.SelectedValue)
                   select new {
                       emp.EMP_FNAME,
                       emp.EMP_LNAME,
                       emp.EMP_COMM,
                       emp.EMP_HIREDATE,
                       emp.EMP_EMAIL,
                       emp.EMP_PHONE,
                       emp.EMP_TITLE
        */
    }
protected void departmentDropDownList1_SelectedIndexChanged(object sender, EventArgs e)
{
    employeeGridView1.DataBind();
}
